import React from 'react';
import "./App.css";

function App() {
   const [value, setValue] = React.useState("");
   const [todos, setTodos] = React.useState([]);
   
   const addTodo = () => {
     let arr = [...todos];
     arr.push(value);
     setTodos(arr);
     setValue("");
   }
   
   const deleteTodos = (i) => {
     setTodos([]);
   }
   
   const editTodo = (id) => {
    const input = document.getElementById(id+"input");
    const editBtn = document.getElementById(id);
    input.disabled = false;
    input.focus();
    editBtn.innerHTML = "Update";
    editBtn.onClick = (id) => updateTodo(id);
   }
   
   const updateTodo = (i) => {
     const value = document.getElementById(i+"input").value;
     let arr = [...todos];
     arr.splice(i, 1, value);
     setTodos(arr);
   }

   const deleteTodo = (i) => {
     let arr = [...todos];
     arr.splice(i, 1);
     setTodos(arr);
   }
   
   return (
     <div className="todo-app">
       <div className="todo-head">
         <div className="todo-heading">
           <h1>Todo App</h1>
         </div>
         <div className="add-btn-div">
           <input value={value} onChange={(e) => setValue(e.target.value)} type="text" placeholder="Enter a task" />
           <button onClick={addTodo}>Add Todo</button>
         </div>
         <div className="del-btn-div">
           <button onClick={deleteTodos}>Delete All</button>
         </div>
       </div>
       <div className="todo-body">
           {todos.map((v, i) => {
             return <> <div key={i} className="flex-div"> <div className="todo"> <input className="disabled" id={i+"input"} value={v} type="text" disabled /> </div> <div className="todo-btns"> <button id={i} onClick={(e) => editTodo(e.target.id)}>Edit</button> <button onClick={() => deleteTodo(i)}>Delete</button> </div> </div> </>
           })}
       </div>
     </div>
   )
}

export default App;